package xyz.sonbn.ircclient.model;

import io.realm.RealmObject;

/**
 * Created by sonbn on 11/22/2017.
 */

public class Message extends RealmObject {
    private String username, content;
}
